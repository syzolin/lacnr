SA-MP GVar Plugin
=================

Preface
-------

This plugin is an extension to the per-player variable (PVar) system
introduced in SA-MP 0.3a with a few key differences:

- Global variables (GVars) that are not linked to any player IDs
- Presence in memory until explicit deletion with DeleteGVar
- Much faster execution time than properties (see SA-MP forum thread
  for benchmarks)

Definitions
-----------

#define GLOBAL_VARTYPE_NONE (0)
#define GLOBAL_VARTYPE_INT (1)
#define GLOBAL_VARTYPE_STRING (2)
#define GLOBAL_VARTYPE_FLOAT (3)

Natives
-------

native SetGVarInt(const name[], value, id = 0);
native GetGVarInt(const name[], id = 0);
native SetGVarString(const name[], const value[], id = 0);
native GetGVarString(const name[], dest[], maxlength = sizeof dest, id = 0);
native SetGVarFloat(const name[], Float:value, id = 0);
native Float:GetGVarFloat(const name[], id = 0);
native DeleteGVar(const name[], id = 0);
native GetGVarsUpperIndex(id = 0);
native GetGVarNameAtIndex(index, dest[], maxlength = sizeof dest, id = 0);
native GetGVarType(const name[], id = 0);

Instructions
------------

Create a directory called "plugins" inside of the server directory if
one does not already exist. Place the plugin file (gvar.dll or
gvar.so) inside of this directory.

Add the following line to server.cfg so that the plugin will load the
next time the server starts: 

Windows:
plugins gvar.dll

Linux:
plugins gvar.so

On Windows, add gvar.inc to the pawno\include folder. Include this
file in any of the scripts the server is running:

#include <gvar>

Recompile the scripts with any desired natives and callbacks provided
by the include file. Start the server.

Notes
-----

- Remember to delete GVars when they are no longer needed,
  particularly when a gamemode or filterscript exits.
- The optional ID, like the player ID in PVars, must be unique.
- GVar names are case-insensitive.

Dependencies
------------

The Windows version requires the Microsoft Visual C++ 2010
Redistributable Package.
